package com.appzbyanandhu.scrollingtabexample;

import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/**
 * Created by Anandhu
 */


public class MainActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private TabViewAdapter tabViewAdapter;
    private TabLayout tabLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager=(ViewPager)findViewById(R.id.viewpager);
        tabLayout=(TabLayout)findViewById(R.id.tabView);

        tabViewAdapter=new TabViewAdapter(getSupportFragmentManager());
        viewPager.setAdapter(tabViewAdapter);

        tabLayout.setupWithViewPager(viewPager); // atatching tablayout with viewpager
        tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE); //Setting tab mode - Scrolled
        tabLayout.setSelectedTabIndicatorColor(getResources().getColor(R.color.colorAccent)); //Setting selected tab indicator color

    }


    public class TabViewAdapter extends FragmentPagerAdapter {
    private Fragment fragment;

        public TabViewAdapter(FragmentManager fm){
            super(fm);

        };

        @Override
        public Fragment getItem(int position) {
            return returnFragment(position); // Calling method for getting the respective fragment based on selection
        }

        @Override
        public int getCount() {
            return 5; // Number of tabs
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "TAB VIEW 1";
                case 1:
                    return "TAB VIEW 2";
                case 2:
                    return "TAB VIEW 3";
                case 3:
                    return "TAB VIEW 4";
                case 4:
                    return "TAB VIEW 5";

            }
            return null;
        }


        public Fragment returnFragment(int position){//Returning Fragment instance based on position
             fragment = null;
            /*I have used this condition because I dont wnt to create multiple Fragments, I am jsut reusing the exsting 2 fragmets
            based on the conditions , You can use switch when you have multiple Tabs with different screens */
            if(position%2==0){
                fragment=new FragmentTab1();
            }else{
                fragment=new FragmentTab2();
            }
            return fragment;
        }
    }
}
