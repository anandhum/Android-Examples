package webservice.samples.anandhu.com.webserviceexample;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.spec.ECField;

public class MainActivity extends AppCompatActivity {

    Button getData;
    TextView result;
    String type;
    private final String CONEECTION_URL ="http://services.groupkt.com/country/get/iso2code/IN";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        result=(TextView) findViewById(R.id.result);
        getData=(Button) findViewById(R.id.getData);
        type="";
        getData.setOnClickListener(

            new  Button.OnClickListener(){
                @Override
                public void onClick(View v) {

                    boolean checkNetwork=checkNetworkAvialbility();
                    if(checkNetwork){
                        Toast.makeText(getApplicationContext(),"Internet is availale"+type,Toast.LENGTH_SHORT).show();
                        new MyDownloadManager().execute(CONEECTION_URL);
                    }else
                        Toast.makeText(getApplicationContext(),"Error !! No Internet Connection",Toast.LENGTH_SHORT).show();
                }
            }


        );




    }

    public boolean checkNetworkAvialbility(){
        boolean avilable=true;

        ConnectivityManager conMgr=(ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ntwrkInfo=conMgr.getActiveNetworkInfo();


        if(ntwrkInfo!=null && ntwrkInfo.isConnected()){
            type=ntwrkInfo.getTypeName();
           avilable=true;
        }else{
            avilable=false;
        }

        return avilable;
    }


    private class MyDownloadManager extends AsyncTask<String, String,String>{
        ProgressDialog dialog;
        int responseCode=0;
        char[] values;
        @Override
        protected String doInBackground(String... params) {


            try {
              return downloadData(params[0]);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        public String downloadData(String url)throws IOException{

            InputStream in;
            int len=1000;

         URL newurl=new URL(url);

            HttpURLConnection urlConnection=(HttpURLConnection)newurl.openConnection();
            urlConnection.setConnectTimeout(10000);
            urlConnection.setReadTimeout(15000);
            urlConnection.setRequestMethod("GET");
            urlConnection.setDoInput(true);

            urlConnection.connect();
             responseCode=urlConnection.getResponseCode();

            in =urlConnection.getInputStream();

            Reader reder=null;
            reder=new InputStreamReader(in,"UTF-8");
           values=new char[len];
            reder.read(values);



            Log.i("responsecode",new String(values)+"");

//            Toast.makeText(getApplicationContext(),"Code :"+responseCode,Toast.LENGTH_SHORT).show();



            return new String(values);
        }

        @Override
        protected void onPreExecute() {
          dialog=new ProgressDialog(MainActivity.this);
            dialog.setTitle("Fetching");
            dialog.setMessage("Waiting...");
            dialog.show();

        }

        @Override
        protected void onPostExecute(String s) {
            dialog.dismiss();

            try{
               JSONObject ob=new JSONObject(s);

                JSONArray ar=null;
                ob.toJSONArray(ar);
                Log.i("responsecode","vaues of json "+ar.getString(0));
//                JSONObject jsonObject=(JSONObject) new JSONParser().parse(s);
//                Log.i("responsecode","vaues od s "+s);
//                result.setText(jsonObject.get("messages")+"");
            }catch (Exception e){
                Log.i("responsecode","error "+e);
                Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
            }

        }

        @Override
        protected void onProgressUpdate(String... values) {
            super.onProgressUpdate(values);
        }
    }
}
